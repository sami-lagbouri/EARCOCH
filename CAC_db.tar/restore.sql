--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE ca_db;
--
-- Name: ca_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE ca_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'French_France.1252' LC_CTYPE = 'French_France.1252';


ALTER DATABASE ca_db OWNER TO postgres;

\connect ca_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: reg_ca; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_ca (
    id_ca integer NOT NULL
);


ALTER TABLE public.reg_ca OWNER TO postgres;

--
-- Name: reg_ca_id_ca_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_ca_id_ca_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_ca_id_ca_seq OWNER TO postgres;

--
-- Name: reg_ca_id_ca_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_ca_id_ca_seq OWNED BY public.reg_ca.id_ca;


--
-- Name: reg_chirg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_chirg (
    id_chirg integer NOT NULL,
    reg_id_dospat integer NOT NULL,
    dtl_imp_chirg integer,
    cot_chirg integer,
    cmnt_chirg character varying(254),
    d_chirg date,
    etat_chirg character varying(254)
);


ALTER TABLE public.reg_chirg OWNER TO postgres;

--
-- Name: reg_chirg_id_chirg_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_chirg_id_chirg_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_chirg_id_chirg_seq OWNER TO postgres;

--
-- Name: reg_chirg_id_chirg_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_chirg_id_chirg_seq OWNED BY public.reg_chirg.id_chirg;


--
-- Name: reg_clin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_clin (
    id_clin integer NOT NULL,
    pav_clin character varying(254),
    condaud_clin character varying(254),
    tymp_clin character varying(254),
    regmast_clin character varying(254),
    vesti_clin character varying(254),
    rhino_clin character varying(254),
    cavbucc_clin character varying(254),
    cervfac_clin character varying(254),
    ophtal_clin character varying(254),
    echcardio_clin character varying(254),
    electrocardio_clin character varying(254),
    oeilopht_clin character varying(254),
    visuopht_clin character varying(254),
    nephro_clin character varying(254),
    neuro_clin character varying(254),
    genet_clin character varying(254),
    statutparfr_clin character varying(254)
);


ALTER TABLE public.reg_clin OWNER TO postgres;

--
-- Name: reg_cmpt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_cmpt (
    id_cmpt integer NOT NULL,
    reg_reg_id_pers integer NOT NULL,
    reg_id_utlr integer NOT NULL,
    log_cmpt character varying(254),
    pass_cmpt character varying(254),
    dc_cmpt date
);


ALTER TABLE public.reg_cmpt OWNER TO postgres;

--
-- Name: reg_cmpt_id_cmpt_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_cmpt_id_cmpt_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_cmpt_id_cmpt_seq OWNER TO postgres;

--
-- Name: reg_cmpt_id_cmpt_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_cmpt_id_cmpt_seq OWNED BY public.reg_cmpt.id_cmpt;


--
-- Name: reg_cnslt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_cnslt (
    id_cnslt integer NOT NULL,
    cr_cnslt character varying(254),
    idpat_cnslt integer,
    coch_cnslt character varying(254)
);


ALTER TABLE public.reg_cnslt OWNER TO postgres;

--
-- Name: reg_cnsult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_cnsult (
    id_cnsult integer NOT NULL,
    idpat_cnsult integer,
    decmed_cnsult character varying(254),
    decfam_cnsult character varying(254),
    crdec_cnsult character varying(254),
    bilanbio_cnsult character varying(254)
);


ALTER TABLE public.reg_cnsult OWNER TO postgres;

--
-- Name: reg_comp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_comp (
    id_comp integer NOT NULL,
    reg_id_dospat integer NOT NULL,
    d_comp date,
    tst_comp character varying(254),
    impl_comp boolean,
    implist_comp boolean,
    autre_comp boolean,
    implpan_comp boolean,
    comp character varying(254),
    od_comp character varying(254),
    og_comp character varying(254),
    cmnt_comp integer
);


ALTER TABLE public.reg_comp OWNER TO postgres;

--
-- Name: reg_comp_id_comp_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_comp_id_comp_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_comp_id_comp_seq OWNER TO postgres;

--
-- Name: reg_comp_id_comp_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_comp_id_comp_seq OWNED BY public.reg_comp.id_comp;


--
-- Name: reg_dospat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_dospat (
    id_dospat integer NOT NULL,
    reg_reg_id_pers integer NOT NULL,
    reg_id_pat integer NOT NULL,
    reg_id_orth integer NOT NULL
);


ALTER TABLE public.reg_dospat OWNER TO postgres;

--
-- Name: reg_dospat_id_dospat_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_dospat_id_dospat_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_dospat_id_dospat_seq OWNER TO postgres;

--
-- Name: reg_dospat_id_dospat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_dospat_id_dospat_seq OWNED BY public.reg_dospat.id_dospat;


--
-- Name: reg_fs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_fs (
    id_fs integer NOT NULL,
    reg_id_dospat integer NOT NULL,
    ds_fs date,
    process_fs character varying(254),
    cmnt_fs integer,
    dpro_fs date
);


ALTER TABLE public.reg_fs OWNER TO postgres;

--
-- Name: reg_fs_id_fs_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_fs_id_fs_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_fs_id_fs_seq OWNER TO postgres;

--
-- Name: reg_fs_id_fs_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_fs_id_fs_seq OWNED BY public.reg_fs.id_fs;


--
-- Name: reg_img; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_img (
    id_img integer NOT NULL,
    reg_id_chirg integer NOT NULL
);


ALTER TABLE public.reg_img OWNER TO postgres;

--
-- Name: reg_img_id_img_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_img_id_img_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_img_id_img_seq OWNER TO postgres;

--
-- Name: reg_img_id_img_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_img_id_img_seq OWNED BY public.reg_img.id_img;


--
-- Name: reg_irm; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_irm (
    reg_id_img integer NOT NULL,
    id_irm integer NOT NULL,
    date_naissance date,
    service character varying(254),
    etat character varying(254),
    nerf_coch_d character varying(254),
    lab_post_d character varying(254),
    cochlee_d character varying(254),
    snc_d character varying(254),
    commentaire_irm character varying(254),
    nerf_coch_g character varying(254),
    lab_post_g character varying(254),
    cochlee_g character varying(254),
    snc_g character varying(254)
);


ALTER TABLE public.reg_irm OWNER TO postgres;

--
-- Name: reg_irm_reg_id_img_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_irm_reg_id_img_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_irm_reg_id_img_seq OWNER TO postgres;

--
-- Name: reg_irm_reg_id_img_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_irm_reg_id_img_seq OWNED BY public.reg_irm.reg_id_img;


--
-- Name: reg_ofr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_ofr (
    id_ofr integer NOT NULL,
    reg_reg_id_pers integer NOT NULL,
    reg_id_pat integer NOT NULL,
    qst_ofr character varying(254),
    re_ofr boolean,
    crtr_ofr character varying(254)
);


ALTER TABLE public.reg_ofr OWNER TO postgres;

--
-- Name: reg_ofr_chirg; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_ofr_chirg (
    reg_id_ofr integer NOT NULL,
    reg_id_chirg integer NOT NULL
);


ALTER TABLE public.reg_ofr_chirg OWNER TO postgres;

--
-- Name: reg_ofr_chirg_reg_id_chirg_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_ofr_chirg_reg_id_chirg_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_ofr_chirg_reg_id_chirg_seq OWNER TO postgres;

--
-- Name: reg_ofr_chirg_reg_id_chirg_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_ofr_chirg_reg_id_chirg_seq OWNED BY public.reg_ofr_chirg.reg_id_chirg;


--
-- Name: reg_ofr_chirg_reg_id_ofr_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_ofr_chirg_reg_id_ofr_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_ofr_chirg_reg_id_ofr_seq OWNER TO postgres;

--
-- Name: reg_ofr_chirg_reg_id_ofr_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_ofr_chirg_reg_id_ofr_seq OWNED BY public.reg_ofr_chirg.reg_id_ofr;


--
-- Name: reg_ofr_id_ofr_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_ofr_id_ofr_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_ofr_id_ofr_seq OWNER TO postgres;

--
-- Name: reg_ofr_id_ofr_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_ofr_id_ofr_seq OWNED BY public.reg_ofr.id_ofr;


--
-- Name: reg_orth; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_orth (
    id_orth integer NOT NULL,
    reg_id_dospat integer NOT NULL,
    pstimpd_orth character varying(254),
    pstimpg_orth character varying(254),
    db_orth date,
    ref_orth character varying(254),
    mrqimpd_orth character varying(254),
    typimpd_orth character varying(254),
    procd_orth character varying(254),
    mrqimpg_orth character varying(254),
    typimpg_orth character varying(254),
    procg_orth character varying(254),
    impbil_orth character varying(254),
    prthcnt_orth character varying(254),
    ddca_orth date,
    ddcr_orth date,
    passv_orth boolean,
    cntr_orth character varying(254),
    orth character varying(254),
    nblib_orth integer,
    nbgrp_orth integer,
    tmps_orth integer,
    aproth_orth character varying(254),
    tpsco_orth character varying(254),
    tnivsco_orth character varying(254),
    cprt_orth integer,
    mpm_orth integer,
    cap_orth integer,
    mais_orth integer,
    muss_orth integer,
    det_orth character varying(254),
    desc_orth character varying(254),
    idnt_orth character varying(254),
    icsl_orth character varying(254),
    tstphn_orth character varying(254),
    cnsn_orth character varying(254),
    voy_orth character varying(254),
    phon_orth integer,
    mot_orth integer,
    alrt_orth character varying(254),
    detb_orth character varying(254),
    lstfrm_orth character varying(254),
    lstouv_orth character varying(254),
    rythm_orth character varying(254)
);


ALTER TABLE public.reg_orth OWNER TO postgres;

--
-- Name: reg_orth_id_orth_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_orth_id_orth_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_orth_id_orth_seq OWNER TO postgres;

--
-- Name: reg_orth_id_orth_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_orth_id_orth_seq OWNED BY public.reg_orth.id_orth;


--
-- Name: reg_pat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_pat (
    id_pat integer NOT NULL,
    reg_id_dospat integer,
    nom_pat character varying(254),
    prenom_pat character varying(254),
    dn_pat date,
    sexe_pat character varying(254),
    adr_pat character varying(254),
    sit_pat character varying(254),
    sco_pat character varying(254),
    etat_pat character varying(254),
    lm_pat character varying(254),
    ville_pat character varying(254),
    cp_pat integer,
    ad_par_pat character varying(254),
    niv_socio_pat character varying(254),
    tel_pat integer,
    lu_pat character varying(254),
    suivi_ortho_pat character varying(254),
    m_comm_pat character varying(254),
    adulte_pat character varying(254),
    fin_pat character varying(254),
    parents_pat character varying(254),
    email_pat character varying(254),
    motif_pat character varying(254),
    check_pat character varying(254),
    pec1_pat character varying(254),
    pec2_pat character varying(254),
    pec3_pat character varying(254),
    typeimp_pat character varying(254),
    mut_pat character varying(254),
    iddos_pat character varying(254)
);


ALTER TABLE public.reg_pat OWNER TO postgres;

--
-- Name: reg_pat_id_pat_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_pat_id_pat_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_pat_id_pat_seq OWNER TO postgres;

--
-- Name: reg_pat_id_pat_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_pat_id_pat_seq OWNED BY public.reg_pat.id_pat;


--
-- Name: reg_pers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_pers (
    id_pers integer NOT NULL,
    reg_id_ca integer NOT NULL,
    cin_pers character varying(254)
);


ALTER TABLE public.reg_pers OWNER TO postgres;

--
-- Name: reg_pers_id_pers_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_pers_id_pers_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_pers_id_pers_seq OWNER TO postgres;

--
-- Name: reg_pers_id_pers_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_pers_id_pers_seq OWNED BY public.reg_pers.id_pers;


--
-- Name: reg_scan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_scan (
    reg_id_img integer NOT NULL,
    id_scan integer NOT NULL,
    dn_scan date,
    srv_scan character varying(254),
    syn_scan character varying(254),
    caid_scan character varying(254),
    caig_scan character varying(254),
    cscg_scan character varying(254),
    cochd_scan character varying(254),
    cochg_scan character varying(254),
    agvd_scan character varying(254),
    agvg_scan character varying(254),
    omoyd_scan character varying(254),
    omoyg_scan character varying(254)
);


ALTER TABLE public.reg_scan OWNER TO postgres;

--
-- Name: reg_scan_id_scan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_scan_id_scan_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_scan_id_scan_seq OWNER TO postgres;

--
-- Name: reg_scan_id_scan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_scan_id_scan_seq OWNED BY public.reg_scan.id_scan;


--
-- Name: reg_surd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_surd (
    id_surd integer NOT NULL,
    reg_id_dospat integer,
    agacq_surd integer,
    poids_surd integer,
    grss_accch_surd character varying(254),
    etlg_surd character varying(254),
    ant_pers_surd character varying(254),
    antcfam_surd character varying(254),
    cnsng_surd character varying(254),
    apgar_surd integer,
    infcong_pre_surd character varying(254),
    sub_pre_surd character varying(254),
    sff_per_surd character varying(254),
    cpost_surd character varying(254),
    trbl_surd character varying(254),
    trbl_syn_surd character varying(254),
    obsrv_surd text,
    orthref_surd integer,
    chir_surd integer,
    ortho_surd integer,
    reg_surd integer,
    audio_surd integer,
    collab_surd character varying(254),
    observinter_surd character varying(254)
);


ALTER TABLE public.reg_surd OWNER TO postgres;

--
-- Name: reg_surd_id_surd_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_surd_id_surd_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_surd_id_surd_seq OWNER TO postgres;

--
-- Name: reg_surd_id_surd_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_surd_id_surd_seq OWNED BY public.reg_surd.id_surd;


--
-- Name: reg_utlr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reg_utlr (
    reg_id_pers integer NOT NULL,
    id_utlr integer NOT NULL,
    reg_id_cmpt integer NOT NULL,
    nom_utlr character varying,
    prenom_utlr character varying,
    adr_utlr character varying,
    tel_utlr character varying,
    email_utlr character varying,
    centre_utlr character varying,
    cabinet_utlr character varying,
    role_utlr character varying
);


ALTER TABLE public.reg_utlr OWNER TO postgres;

--
-- Name: reg_utlr_id_utlr_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.reg_utlr_id_utlr_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.reg_utlr_id_utlr_seq OWNER TO postgres;

--
-- Name: reg_utlr_id_utlr_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.reg_utlr_id_utlr_seq OWNED BY public.reg_utlr.id_utlr;


--
-- Name: rtetezrt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rtetezrt (
    ertert "char"[] NOT NULL
);


ALTER TABLE public.rtetezrt OWNER TO postgres;

--
-- Name: reg_ca id_ca; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ca ALTER COLUMN id_ca SET DEFAULT nextval('public.reg_ca_id_ca_seq'::regclass);


--
-- Name: reg_chirg id_chirg; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_chirg ALTER COLUMN id_chirg SET DEFAULT nextval('public.reg_chirg_id_chirg_seq'::regclass);


--
-- Name: reg_cmpt id_cmpt; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_cmpt ALTER COLUMN id_cmpt SET DEFAULT nextval('public.reg_cmpt_id_cmpt_seq'::regclass);


--
-- Name: reg_comp id_comp; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_comp ALTER COLUMN id_comp SET DEFAULT nextval('public.reg_comp_id_comp_seq'::regclass);


--
-- Name: reg_dospat id_dospat; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_dospat ALTER COLUMN id_dospat SET DEFAULT nextval('public.reg_dospat_id_dospat_seq'::regclass);


--
-- Name: reg_fs id_fs; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_fs ALTER COLUMN id_fs SET DEFAULT nextval('public.reg_fs_id_fs_seq'::regclass);


--
-- Name: reg_img id_img; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_img ALTER COLUMN id_img SET DEFAULT nextval('public.reg_img_id_img_seq'::regclass);


--
-- Name: reg_irm reg_id_img; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_irm ALTER COLUMN reg_id_img SET DEFAULT nextval('public.reg_irm_reg_id_img_seq'::regclass);


--
-- Name: reg_ofr id_ofr; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ofr ALTER COLUMN id_ofr SET DEFAULT nextval('public.reg_ofr_id_ofr_seq'::regclass);


--
-- Name: reg_ofr_chirg reg_id_ofr; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ofr_chirg ALTER COLUMN reg_id_ofr SET DEFAULT nextval('public.reg_ofr_chirg_reg_id_ofr_seq'::regclass);


--
-- Name: reg_ofr_chirg reg_id_chirg; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ofr_chirg ALTER COLUMN reg_id_chirg SET DEFAULT nextval('public.reg_ofr_chirg_reg_id_chirg_seq'::regclass);


--
-- Name: reg_orth id_orth; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_orth ALTER COLUMN id_orth SET DEFAULT nextval('public.reg_orth_id_orth_seq'::regclass);


--
-- Name: reg_pat id_pat; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_pat ALTER COLUMN id_pat SET DEFAULT nextval('public.reg_pat_id_pat_seq'::regclass);


--
-- Name: reg_pers id_pers; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_pers ALTER COLUMN id_pers SET DEFAULT nextval('public.reg_pers_id_pers_seq'::regclass);


--
-- Name: reg_scan id_scan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_scan ALTER COLUMN id_scan SET DEFAULT nextval('public.reg_scan_id_scan_seq'::regclass);


--
-- Name: reg_surd id_surd; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_surd ALTER COLUMN id_surd SET DEFAULT nextval('public.reg_surd_id_surd_seq'::regclass);


--
-- Name: reg_utlr id_utlr; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_utlr ALTER COLUMN id_utlr SET DEFAULT nextval('public.reg_utlr_id_utlr_seq'::regclass);


--
-- Data for Name: reg_ca; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_ca (id_ca) FROM stdin;
\.
COPY public.reg_ca (id_ca) FROM '$$PATH$$/3016.dat';

--
-- Data for Name: reg_chirg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_chirg (id_chirg, reg_id_dospat, dtl_imp_chirg, cot_chirg, cmnt_chirg, d_chirg, etat_chirg) FROM stdin;
\.
COPY public.reg_chirg (id_chirg, reg_id_dospat, dtl_imp_chirg, cot_chirg, cmnt_chirg, d_chirg, etat_chirg) FROM '$$PATH$$/3018.dat';

--
-- Data for Name: reg_clin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_clin (id_clin, pav_clin, condaud_clin, tymp_clin, regmast_clin, vesti_clin, rhino_clin, cavbucc_clin, cervfac_clin, ophtal_clin, echcardio_clin, electrocardio_clin, oeilopht_clin, visuopht_clin, nephro_clin, neuro_clin, genet_clin, statutparfr_clin) FROM stdin;
\.
COPY public.reg_clin (id_clin, pav_clin, condaud_clin, tymp_clin, regmast_clin, vesti_clin, rhino_clin, cavbucc_clin, cervfac_clin, ophtal_clin, echcardio_clin, electrocardio_clin, oeilopht_clin, visuopht_clin, nephro_clin, neuro_clin, genet_clin, statutparfr_clin) FROM '$$PATH$$/3052.dat';

--
-- Data for Name: reg_cmpt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_cmpt (id_cmpt, reg_reg_id_pers, reg_id_utlr, log_cmpt, pass_cmpt, dc_cmpt) FROM stdin;
\.
COPY public.reg_cmpt (id_cmpt, reg_reg_id_pers, reg_id_utlr, log_cmpt, pass_cmpt, dc_cmpt) FROM '$$PATH$$/3020.dat';

--
-- Data for Name: reg_cnslt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_cnslt (id_cnslt, cr_cnslt, idpat_cnslt, coch_cnslt) FROM stdin;
\.
COPY public.reg_cnslt (id_cnslt, cr_cnslt, idpat_cnslt, coch_cnslt) FROM '$$PATH$$/3050.dat';

--
-- Data for Name: reg_cnsult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_cnsult (id_cnsult, idpat_cnsult, decmed_cnsult, decfam_cnsult, crdec_cnsult, bilanbio_cnsult) FROM stdin;
\.
COPY public.reg_cnsult (id_cnsult, idpat_cnsult, decmed_cnsult, decfam_cnsult, crdec_cnsult, bilanbio_cnsult) FROM '$$PATH$$/3051.dat';

--
-- Data for Name: reg_comp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_comp (id_comp, reg_id_dospat, d_comp, tst_comp, impl_comp, implist_comp, autre_comp, implpan_comp, comp, od_comp, og_comp, cmnt_comp) FROM stdin;
\.
COPY public.reg_comp (id_comp, reg_id_dospat, d_comp, tst_comp, impl_comp, implist_comp, autre_comp, implpan_comp, comp, od_comp, og_comp, cmnt_comp) FROM '$$PATH$$/3022.dat';

--
-- Data for Name: reg_dospat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_dospat (id_dospat, reg_reg_id_pers, reg_id_pat, reg_id_orth) FROM stdin;
\.
COPY public.reg_dospat (id_dospat, reg_reg_id_pers, reg_id_pat, reg_id_orth) FROM '$$PATH$$/3024.dat';

--
-- Data for Name: reg_fs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_fs (id_fs, reg_id_dospat, ds_fs, process_fs, cmnt_fs, dpro_fs) FROM stdin;
\.
COPY public.reg_fs (id_fs, reg_id_dospat, ds_fs, process_fs, cmnt_fs, dpro_fs) FROM '$$PATH$$/3026.dat';

--
-- Data for Name: reg_img; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_img (id_img, reg_id_chirg) FROM stdin;
\.
COPY public.reg_img (id_img, reg_id_chirg) FROM '$$PATH$$/3028.dat';

--
-- Data for Name: reg_irm; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_irm (reg_id_img, id_irm, date_naissance, service, etat, nerf_coch_d, lab_post_d, cochlee_d, snc_d, commentaire_irm, nerf_coch_g, lab_post_g, cochlee_g, snc_g) FROM stdin;
\.
COPY public.reg_irm (reg_id_img, id_irm, date_naissance, service, etat, nerf_coch_d, lab_post_d, cochlee_d, snc_d, commentaire_irm, nerf_coch_g, lab_post_g, cochlee_g, snc_g) FROM '$$PATH$$/3030.dat';

--
-- Data for Name: reg_ofr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_ofr (id_ofr, reg_reg_id_pers, reg_id_pat, qst_ofr, re_ofr, crtr_ofr) FROM stdin;
\.
COPY public.reg_ofr (id_ofr, reg_reg_id_pers, reg_id_pat, qst_ofr, re_ofr, crtr_ofr) FROM '$$PATH$$/3032.dat';

--
-- Data for Name: reg_ofr_chirg; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_ofr_chirg (reg_id_ofr, reg_id_chirg) FROM stdin;
\.
COPY public.reg_ofr_chirg (reg_id_ofr, reg_id_chirg) FROM '$$PATH$$/3033.dat';

--
-- Data for Name: reg_orth; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_orth (id_orth, reg_id_dospat, pstimpd_orth, pstimpg_orth, db_orth, ref_orth, mrqimpd_orth, typimpd_orth, procd_orth, mrqimpg_orth, typimpg_orth, procg_orth, impbil_orth, prthcnt_orth, ddca_orth, ddcr_orth, passv_orth, cntr_orth, orth, nblib_orth, nbgrp_orth, tmps_orth, aproth_orth, tpsco_orth, tnivsco_orth, cprt_orth, mpm_orth, cap_orth, mais_orth, muss_orth, det_orth, desc_orth, idnt_orth, icsl_orth, tstphn_orth, cnsn_orth, voy_orth, phon_orth, mot_orth, alrt_orth, detb_orth, lstfrm_orth, lstouv_orth, rythm_orth) FROM stdin;
\.
COPY public.reg_orth (id_orth, reg_id_dospat, pstimpd_orth, pstimpg_orth, db_orth, ref_orth, mrqimpd_orth, typimpd_orth, procd_orth, mrqimpg_orth, typimpg_orth, procg_orth, impbil_orth, prthcnt_orth, ddca_orth, ddcr_orth, passv_orth, cntr_orth, orth, nblib_orth, nbgrp_orth, tmps_orth, aproth_orth, tpsco_orth, tnivsco_orth, cprt_orth, mpm_orth, cap_orth, mais_orth, muss_orth, det_orth, desc_orth, idnt_orth, icsl_orth, tstphn_orth, cnsn_orth, voy_orth, phon_orth, mot_orth, alrt_orth, detb_orth, lstfrm_orth, lstouv_orth, rythm_orth) FROM '$$PATH$$/3037.dat';

--
-- Data for Name: reg_pat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_pat (id_pat, reg_id_dospat, nom_pat, prenom_pat, dn_pat, sexe_pat, adr_pat, sit_pat, sco_pat, etat_pat, lm_pat, ville_pat, cp_pat, ad_par_pat, niv_socio_pat, tel_pat, lu_pat, suivi_ortho_pat, m_comm_pat, adulte_pat, fin_pat, parents_pat, email_pat, motif_pat, check_pat, pec1_pat, pec2_pat, pec3_pat, typeimp_pat, mut_pat, iddos_pat) FROM stdin;
\.
COPY public.reg_pat (id_pat, reg_id_dospat, nom_pat, prenom_pat, dn_pat, sexe_pat, adr_pat, sit_pat, sco_pat, etat_pat, lm_pat, ville_pat, cp_pat, ad_par_pat, niv_socio_pat, tel_pat, lu_pat, suivi_ortho_pat, m_comm_pat, adulte_pat, fin_pat, parents_pat, email_pat, motif_pat, check_pat, pec1_pat, pec2_pat, pec3_pat, typeimp_pat, mut_pat, iddos_pat) FROM '$$PATH$$/3045.dat';

--
-- Data for Name: reg_pers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_pers (id_pers, reg_id_ca, cin_pers) FROM stdin;
\.
COPY public.reg_pers (id_pers, reg_id_ca, cin_pers) FROM '$$PATH$$/3039.dat';

--
-- Data for Name: reg_scan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_scan (reg_id_img, id_scan, dn_scan, srv_scan, syn_scan, caid_scan, caig_scan, cscg_scan, cochd_scan, cochg_scan, agvd_scan, agvg_scan, omoyd_scan, omoyg_scan) FROM stdin;
\.
COPY public.reg_scan (reg_id_img, id_scan, dn_scan, srv_scan, syn_scan, caid_scan, caig_scan, cscg_scan, cochd_scan, cochg_scan, agvd_scan, agvg_scan, omoyd_scan, omoyg_scan) FROM '$$PATH$$/3041.dat';

--
-- Data for Name: reg_surd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_surd (id_surd, reg_id_dospat, agacq_surd, poids_surd, grss_accch_surd, etlg_surd, ant_pers_surd, antcfam_surd, cnsng_surd, apgar_surd, infcong_pre_surd, sub_pre_surd, sff_per_surd, cpost_surd, trbl_surd, trbl_syn_surd, obsrv_surd, orthref_surd, chir_surd, ortho_surd, reg_surd, audio_surd, collab_surd, observinter_surd) FROM stdin;
\.
COPY public.reg_surd (id_surd, reg_id_dospat, agacq_surd, poids_surd, grss_accch_surd, etlg_surd, ant_pers_surd, antcfam_surd, cnsng_surd, apgar_surd, infcong_pre_surd, sub_pre_surd, sff_per_surd, cpost_surd, trbl_surd, trbl_syn_surd, obsrv_surd, orthref_surd, chir_surd, ortho_surd, reg_surd, audio_surd, collab_surd, observinter_surd) FROM '$$PATH$$/3047.dat';

--
-- Data for Name: reg_utlr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reg_utlr (reg_id_pers, id_utlr, reg_id_cmpt, nom_utlr, prenom_utlr, adr_utlr, tel_utlr, email_utlr, centre_utlr, cabinet_utlr, role_utlr) FROM stdin;
\.
COPY public.reg_utlr (reg_id_pers, id_utlr, reg_id_cmpt, nom_utlr, prenom_utlr, adr_utlr, tel_utlr, email_utlr, centre_utlr, cabinet_utlr, role_utlr) FROM '$$PATH$$/3043.dat';

--
-- Data for Name: rtetezrt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rtetezrt (ertert) FROM stdin;
\.
COPY public.rtetezrt (ertert) FROM '$$PATH$$/3049.dat';

--
-- Name: reg_ca_id_ca_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_ca_id_ca_seq', 1, false);


--
-- Name: reg_chirg_id_chirg_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_chirg_id_chirg_seq', 1, false);


--
-- Name: reg_cmpt_id_cmpt_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_cmpt_id_cmpt_seq', 1, false);


--
-- Name: reg_comp_id_comp_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_comp_id_comp_seq', 1, false);


--
-- Name: reg_dospat_id_dospat_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_dospat_id_dospat_seq', 1, false);


--
-- Name: reg_fs_id_fs_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_fs_id_fs_seq', 1, false);


--
-- Name: reg_img_id_img_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_img_id_img_seq', 1, false);


--
-- Name: reg_irm_reg_id_img_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_irm_reg_id_img_seq', 1, false);


--
-- Name: reg_ofr_chirg_reg_id_chirg_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_ofr_chirg_reg_id_chirg_seq', 1, false);


--
-- Name: reg_ofr_chirg_reg_id_ofr_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_ofr_chirg_reg_id_ofr_seq', 1, false);


--
-- Name: reg_ofr_id_ofr_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_ofr_id_ofr_seq', 1, false);


--
-- Name: reg_orth_id_orth_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_orth_id_orth_seq', 1, false);


--
-- Name: reg_pat_id_pat_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_pat_id_pat_seq', 102, true);


--
-- Name: reg_pers_id_pers_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_pers_id_pers_seq', 1, false);


--
-- Name: reg_scan_id_scan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_scan_id_scan_seq', 1, false);


--
-- Name: reg_surd_id_surd_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_surd_id_surd_seq', 1, false);


--
-- Name: reg_utlr_id_utlr_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reg_utlr_id_utlr_seq', 1, false);


--
-- Name: reg_pers ak_identifiant_1_reg_pers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_pers
    ADD CONSTRAINT ak_identifiant_1_reg_pers PRIMARY KEY (id_pers);


--
-- Name: reg_ofr_chirg pk_reg_ofr_chirg; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ofr_chirg
    ADD CONSTRAINT pk_reg_ofr_chirg PRIMARY KEY (reg_id_ofr, reg_id_chirg);


--
-- Name: reg_ca reg_ca_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ca
    ADD CONSTRAINT reg_ca_pkey PRIMARY KEY (id_ca);


--
-- Name: reg_chirg reg_chirg_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_chirg
    ADD CONSTRAINT reg_chirg_pkey PRIMARY KEY (id_chirg);


--
-- Name: reg_clin reg_clin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_clin
    ADD CONSTRAINT reg_clin_pkey PRIMARY KEY (id_clin);


--
-- Name: reg_cmpt reg_cmpt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_cmpt
    ADD CONSTRAINT reg_cmpt_pkey PRIMARY KEY (id_cmpt);


--
-- Name: reg_cnslt reg_cnslt1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_cnslt
    ADD CONSTRAINT reg_cnslt1_pkey PRIMARY KEY (id_cnslt);


--
-- Name: reg_cnsult reg_cnsult_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_cnsult
    ADD CONSTRAINT reg_cnsult_pkey PRIMARY KEY (id_cnsult);


--
-- Name: reg_comp reg_comp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_comp
    ADD CONSTRAINT reg_comp_pkey PRIMARY KEY (id_comp);


--
-- Name: reg_dospat reg_dospat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_dospat
    ADD CONSTRAINT reg_dospat_pkey PRIMARY KEY (id_dospat);


--
-- Name: reg_fs reg_fs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_fs
    ADD CONSTRAINT reg_fs_pkey PRIMARY KEY (id_fs);


--
-- Name: reg_img reg_img_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_img
    ADD CONSTRAINT reg_img_pkey PRIMARY KEY (id_img);


--
-- Name: reg_irm reg_irm_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_irm
    ADD CONSTRAINT reg_irm_pkey PRIMARY KEY (reg_id_img);


--
-- Name: reg_ofr reg_ofr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_ofr
    ADD CONSTRAINT reg_ofr_pkey PRIMARY KEY (id_ofr);


--
-- Name: reg_orth reg_orth_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_orth
    ADD CONSTRAINT reg_orth_pkey PRIMARY KEY (id_orth);


--
-- Name: reg_pat reg_pat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_pat
    ADD CONSTRAINT reg_pat_pkey PRIMARY KEY (id_pat);


--
-- Name: reg_scan reg_scan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_scan
    ADD CONSTRAINT reg_scan_pkey PRIMARY KEY (id_scan);


--
-- Name: reg_surd reg_surd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_surd
    ADD CONSTRAINT reg_surd_pkey PRIMARY KEY (id_surd);


--
-- Name: reg_utlr reg_utlr_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_utlr
    ADD CONSTRAINT reg_utlr_pkey PRIMARY KEY (id_utlr);


--
-- Name: comp_dospat_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX comp_dospat_fk ON public.reg_comp USING btree (reg_id_dospat);


--
-- Name: generalisation_3_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generalisation_3_fk ON public.reg_utlr USING btree (reg_id_pers);


--
-- Name: img_chirg_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX img_chirg_fk ON public.reg_img USING btree (reg_id_chirg);


--
-- Name: orth_dospat_fk2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX orth_dospat_fk2 ON public.reg_orth USING btree (reg_id_dospat);


--
-- Name: pers_ca_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pers_ca_fk ON public.reg_pers USING btree (reg_id_ca);


--
-- Name: pers_pat_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pers_pat_fk ON public.reg_ofr USING btree (reg_reg_id_pers, reg_id_pat);


--
-- Name: pers_utlr_fk2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pers_utlr_fk2 ON public.reg_cmpt USING btree (reg_reg_id_pers, reg_id_utlr);


--
-- Name: reg_ca_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_ca_pk ON public.reg_ca USING btree (id_ca);


--
-- Name: reg_chirg_dospat_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_chirg_dospat_fk ON public.reg_chirg USING btree (reg_id_dospat);


--
-- Name: reg_chirg_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_chirg_pk ON public.reg_chirg USING btree (id_chirg);


--
-- Name: reg_cmpt_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_cmpt_pk ON public.reg_cmpt USING btree (id_cmpt);


--
-- Name: reg_comp_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_comp_pk ON public.reg_comp USING btree (id_comp);


--
-- Name: reg_dospat_orth_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_dospat_orth_fk ON public.reg_dospat USING btree (reg_id_orth);


--
-- Name: reg_dospat_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_dospat_pk ON public.reg_dospat USING btree (id_dospat);


--
-- Name: reg_fs_dospat_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_fs_dospat_fk ON public.reg_fs USING btree (reg_id_dospat);


--
-- Name: reg_fs_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_fs_pk ON public.reg_fs USING btree (id_fs);


--
-- Name: reg_img_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_img_pk ON public.reg_img USING btree (id_img);


--
-- Name: reg_irm_img_4_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_irm_img_4_fk ON public.reg_irm USING btree (reg_id_img);


--
-- Name: reg_irm_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_irm_pk ON public.reg_irm USING btree (reg_id_img, id_irm);


--
-- Name: reg_ofr_chirg_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_ofr_chirg_fk ON public.reg_ofr_chirg USING btree (reg_id_ofr);


--
-- Name: reg_ofr_chirg_fk2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_ofr_chirg_fk2 ON public.reg_ofr_chirg USING btree (reg_id_chirg);


--
-- Name: reg_ofr_chirg_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_ofr_chirg_pk ON public.reg_ofr_chirg USING btree (reg_id_ofr, reg_id_chirg);


--
-- Name: reg_ofr_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_ofr_pk ON public.reg_ofr USING btree (id_ofr);


--
-- Name: reg_orth_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_orth_pk ON public.reg_orth USING btree (id_orth);


--
-- Name: reg_pers_pat_fk2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reg_pers_pat_fk2 ON public.reg_dospat USING btree (reg_reg_id_pers, reg_id_pat);


--
-- Name: reg_pers_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_pers_pk ON public.reg_pers USING btree (id_pers);


--
-- Name: reg_scan_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_scan_pk ON public.reg_scan USING btree (reg_id_img, id_scan);


--
-- Name: reg_surd_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_surd_pk ON public.reg_surd USING btree (id_surd);


--
-- Name: reg_utlr_pk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX reg_utlr_pk ON public.reg_utlr USING btree (reg_id_pers, id_utlr);


--
-- Name: scan_img_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX scan_img_fk ON public.reg_scan USING btree (reg_id_img);


--
-- Name: surd_dospat_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX surd_dospat_fk ON public.reg_surd USING btree (reg_id_dospat);


--
-- Name: utlr_cmpt_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX utlr_cmpt_fk ON public.reg_utlr USING btree (reg_id_cmpt);


--
-- Name: reg_cnslt FK_idpat_cnslt; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reg_cnslt
    ADD CONSTRAINT "FK_idpat_cnslt" FOREIGN KEY (idpat_cnslt) REFERENCES public.reg_pat(id_pat);


--
-- PostgreSQL database dump complete
--

